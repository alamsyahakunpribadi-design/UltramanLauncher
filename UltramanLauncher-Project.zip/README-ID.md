# Ultraman Fighting Evolution Rebirth — Android Launcher

Launcher fan-made Android untuk memilih file ISO milik sendiri dan mencoba membukanya melalui AetherSX2. Ini **bukan port native game PS2** dan bukan emulator.

## Build APK tanpa Android Studio (GitHub Actions)

1. Unduh dan ekstrak ZIP proyek ini.
2. Masuk ke https://github.com dan login.
3. Tekan **New repository**. Beri nama `UltramanLauncher`, pilih **Public** atau **Private**, lalu Create repository.
4. Pada halaman repository, pilih **Add file → Upload files**.
5. Upload seluruh ISI folder proyek (termasuk folder `.github`). Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload. Jika folder `.github` tersembunyi di pengelola file Android, aktifkan tampilkan file tersembunyi atau upload lewat browser desktop.
6. Tekan **Commit changes**.
7. Buka tab **Actions** → workflow **Build Android APK** → **Run workflow** (jika belum otomatis berjalan).
8. Tunggu sampai proses selesai dengan tanda centang hijau.
9. Buka hasil run, gulir ke **Artifacts**, lalu unduh `Ultraman-Launcher-APK`.
10. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di HP. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

## Cara menggunakan

1. Pastikan AetherSX2 sudah terpasang.
2. Buka **Ultraman FE Rebirth**.
3. Tekan **PILIH FILE ISO**, lalu pilih ISO game yang Anda miliki.
4. Tekan **BUKA DI AETHERSX2**.
5. Jika AetherSX2 tidak menerima ISO melalui intent pada versi yang terpasang, buka AetherSX2 dan pilih ISO lewat menu pemilihan game di emulator.

## Catatan penting

- Game PS2 tidak dapat dijadikan APK native Android hanya dengan mengganti ekstensi. Port native membutuhkan source code game dan proses porting besar.
- Proyek ini tidak menyertakan ISO game, BIOS, atau file berhak cipta.
- AetherSX2 memiliki variasi versi; dukungan membuka ISO melalui intent tidak dijamin. Launcher tetap mencoba mengirim URI ISO dan menyediakan catatan fallback.
- APK yang dihasilkan adalah **debug APK** untuk instalasi/pengujian pribadi, belum ditandatangani sebagai rilis distribusi Play Store.
