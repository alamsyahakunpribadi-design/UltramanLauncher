package com.ultraman.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_ISO = 1001;
    private Uri selectedIso;
    private TextView fileLabel;

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 20, 30)));
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(30), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(12,12,14));

        TextView emblem = text("ULTRA", 42, Color.rgb(235,35,45), true);
        root.addView(emblem, new LinearLayout.LayoutParams(-1, dp(65)));
        TextView title = text("FIGHTING EVOLUTION\nREBIRTH", 22, Color.WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(76)));

        TextView subtitle = text("PS2 GAME LAUNCHER", 12, Color.rgb(190,190,190), true);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, dp(36));
        subp.bottomMargin = dp(22);
        root.addView(subtitle, subp);

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(190,20,30));
        root.addView(line, new LinearLayout.LayoutParams(dp(90), dp(3)));

        TextView info = text("Pilih file ISO game milik Anda, lalu buka melalui AetherSX2.", 15, Color.WHITE, false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(76));
        ip.topMargin = dp(20);
        root.addView(info, ip);

        Button choose = button("PILIH FILE ISO");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(56));
        bp.topMargin = dp(12);
        root.addView(choose, bp);
        choose.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-iso9660-image"});
            startActivityForResult(pick, PICK_ISO);
        });

        fileLabel = text("Belum ada file ISO dipilih", 13, Color.LTGRAY, false);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, dp(62));
        flp.topMargin = dp(8);
        root.addView(fileLabel, flp);

        Button play = button("BUKA DI AETHERSX2");
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(56));
        pp.topMargin = dp(12);
        root.addView(play, pp);
        play.setOnClickListener(v -> openGame());

        TextView note = text("Catatan: kompatibilitas pembukaan ISO langsung bergantung pada versi AetherSX2. Jika tidak otomatis terbuka, pilih ISO dari menu Load Game di AetherSX2.", 12, Color.rgb(180,180,180), false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, dp(100));
        np.topMargin = dp(20);
        root.addView(note, np);

        TextView footer = text("FAN-MADE LAUNCHER • GAME/BIOS TIDAK DISERTAKAN", 10, Color.rgb(130,130,130), true);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(48));
        fp.topMargin = dp(18);
        root.addView(footer, fp);

        setContentView(root);
    }

    private void openGame() {
        if (selectedIso == null) {
            Toast.makeText(this, "Pilih file ISO terlebih dahulu.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(selectedIso, "application/octet-stream");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setPackage("com.aethersx2.android");
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent fallback = getPackageManager().getLaunchIntentForPackage("com.aethersx2.android");
                if (fallback != null) startActivity(fallback);
                else Toast.makeText(this, "AetherSX2 belum terpasang. Instal emulator terlebih dahulu.", Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
                Toast.makeText(this, "Tidak dapat membuka AetherSX2. Buka ISO dari menu Load Game emulator.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ISO && resultCode == Activity.RESULT_OK && data != null) {
            selectedIso = data.getData();
            if (selectedIso != null) {
                try { getContentResolver().takePersistableUriPermission(selectedIso, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) {}
                String name = selectedIso.getLastPathSegment();
                fileLabel.setText("ISO dipilih:\n" + (name == null ? selectedIso.toString() : name));
            }
        }
    }
}
